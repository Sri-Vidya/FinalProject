package com.capg.paymentwallet.bean;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.capg.paymentwallet.exception.CustomerException;

@Entity
@Table(name = "wallet_customer")
public class CustomerBean {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cid;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	private String name;
	private String emailId;
	private BigInteger phNo;
	private Integer age;
	

	public String getName() {
		return name.toUpperCase();
	}
	public void setName(String name) {
		
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		
		this.emailId = emailId;
	}
	public BigInteger getPhNo() {
		return phNo;
	}
	public void setPhNo(BigInteger phNo) {
		
		this.phNo = phNo;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) throws Exception {
		
		this.age = age;
	}
	
	
	@Override
	public String toString() {
		return "CustomerBean [cid=" + cid + ", name=" + name + ", emailId="
				+ emailId + ", phNo=" + phNo + ", age=" + age + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cid;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerBean other = (CustomerBean) obj;
		if (cid != other.cid)
			return false;
		return true;
	}
	
	
	
	
}
	