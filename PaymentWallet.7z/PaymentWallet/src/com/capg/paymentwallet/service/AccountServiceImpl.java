package com.capg.paymentwallet.service;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.dao.AccountDaoImpl;
import com.capg.paymentwallet.dao.IAccountDao;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.exception.CustomerExceptionMessage;

public class AccountServiceImpl implements IAccountService{

	@Override
	public boolean createAccount(AccountBean accountBean) throws Exception {
		validateCustomer(accountBean);
		IAccountDao dao=new AccountDaoImpl();
		boolean result=dao.createAccount(accountBean);
		return result;
	}

	@Override
	public AccountBean findAccount(int accountId) throws Exception {
		IAccountDao dao=new AccountDaoImpl();
		AccountBean bean=dao.findAccount(accountId);
		return bean;
		
	}

	@Override
	public boolean deposit(AccountBean accountBean, double depositAmount)
			throws Exception {
		accountBean.setBalance(accountBean.getBalance()+depositAmount);
		IAccountDao dao=new AccountDaoImpl();
		boolean result=dao.updateAccount(accountBean);
		return result;
	
		
	}

	@Override
	public boolean withdraw(AccountBean accountBean, double withdrawAmount)
			throws Exception {
		accountBean.setBalance(accountBean.getBalance()-withdrawAmount);
		IAccountDao dao=new AccountDaoImpl();
		boolean result=dao.updateAccount(accountBean);
		return result;
		
		
	}

	@Override
	public boolean fundTransfer(AccountBean transferingAccountBean,
			AccountBean beneficiaryAccountBean, double transferAmount)
			throws Exception {
		
		transferingAccountBean.setBalance(transferingAccountBean.getBalance()-transferAmount);
		beneficiaryAccountBean.setBalance(beneficiaryAccountBean.getBalance()+transferAmount);
		
		IAccountDao dao=new AccountDaoImpl();
		boolean result1=dao.updateAccount(transferingAccountBean);
		boolean result2=dao.updateAccount(beneficiaryAccountBean);
		return result1 && result2;
		
	}
	
	public boolean validateCustomer(AccountBean accountBean) throws CustomerException{
		boolean isValid=true;
		if(accountBean.getCustomerBean().getName()==null || !(accountBean.getCustomerBean().getName().trim().matches("[A-Za-z]{4,12}"))  ){
			throw new CustomerException(CustomerExceptionMessage.ERROR1);
		}
		
		if(accountBean.getCustomerBean().getEmailId()==null || !(accountBean.getCustomerBean().getEmailId().matches("[a-z0-9_.]+@[a-z]+\\.[a-z]{2,4}"))){
			throw new CustomerException(CustomerExceptionMessage.ERROR2);
		}
		
		if( !(accountBean.getCustomerBean().getAge()>18)){
			throw new CustomerException(CustomerExceptionMessage.ERROR3);
			
		}
		
		if(accountBean.getCustomerBean().getPhNo()==null && !accountBean.getCustomerBean().getPhNo().toString().matches("^[7-9][0-9]{9}")) {
			throw new CustomerException(CustomerExceptionMessage.ERROR4);
		}
		
	
		
		
return isValid;
	
	
	}

}

